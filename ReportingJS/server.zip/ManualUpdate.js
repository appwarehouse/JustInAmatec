module.exports = function (app, firebaseapp, fs, bigquery) {
    try{
        // Update
        // Get all events keys from firebase database
        

    } catch(e){
        console.log(e)
    }
}